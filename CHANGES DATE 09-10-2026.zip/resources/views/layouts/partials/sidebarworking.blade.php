<aside class="sidebar" id="sidebar">
    @php
        // Get the authenticated user
        $user = Auth::user();
    
    @endphp

    <div class="d-flex align-items-center justify-content-center gap-2 text-center py-4 border-bottom border-white border-opacity-25">
        <img src="{{ asset('logo/iflsglogo.png') }}" alt="IFL Solidarity Group" style="width:28px;height:28px;object-fit:contain;">
        <h5 class="text-white mb-0">
            <span id="logo-text">IFL Solidarity</span>
        </h5>
    </div>
    <!-- <div class="px-3 py-4 border-bottom border-white border-opacity-25">
        <div class="d-flex align-items-center">
            <div class="user-avatar me-3">
                {{ strtoupper(substr($user->username ?? 'U', 0, 2)) }}
            </div>
            <div class="user-info d-flex flex-column">
                <h6 class="mb-0 text-white">{{ $user->username }}</h6>
                <small class="text-light">
                    @php
                        $role = $user->role;
                        $roleClass = 'badge-' . str_replace('_', '-', strtolower($role));
                    @endphp
                </small>
            </div>
        </div>
    </div> -->

    <nav class="nav flex-column p-3">

        {{-- ================= 1. DAILY WORK DASHBOARD ================= --}}
        @can('view-working-side')
        <a href="{{ route('workingside') }}" 
        class="nav-link {{ Request::is('workingside*') ? 'active' : '' }}">
            <i class="fas fa-tasks me-1"></i> 
            <span>Working Side</span>
        </a>
        @endcan


        {{-- ── Procurement Menu ── --}}
        @can('view-purchase-orders-menu')
        <div class="nav-item">
            <a href="#procurementSubmenu" class="nav-link" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="procurementSubmenu">
                <i class="fas fa-shopping-cart me-2"></i>
                <span>Procurement Menu</span>
                <i class="fas fa-chevron-down ms-auto transition-toggle"></i>
            </a>

            <div class="collapse" id="procurementSubmenu">
                <div class="ps-4 mt-2">

                    {{-- ── Purchase Requests ── --}}
                    @can('view-purchase-orders-for-procurement')
                        <a href="{{ route('purchaseRequest') }}" class="nav-link d-flex align-items-center"> <i class="fas fa-boxes-packing me-2"></i> <span>Purchase Requests</span> </a>
                        <a href="{{ route('createpurchaseRequest') }}" class="nav-link d-flex align-items-center"> <i class="fas fa-cart-plus me-2"></i> <span>New Purchase Request</span> </a>
                    @endcan

                    {{-- ── Purchase Request Approvals ── --}}
                    @if(
                        auth()->user()->can('view-purchase-request-level-1') ||
                        auth()->user()->can('view-purchase-request-level-2') ||
                        auth()->user()->can('view-purchase-request-level-3') ||
                        auth()->user()->can('view-purchase-request-level-4') ||
                        auth()->user()->can('view-purchase-request-level-5') ||
                        auth()->user()->can('view-purchase-request-level-6')
                    )
                        <div class="mt-3 mb-2">
                            <span class="text-muted small d-flex fw-bold text-uppercase"> <i class="fas fa-clipboard-check me-2"></i> Purchase Request Approvals </span>
                        </div>

                        @can('view-purchase-request-level-1')
                            <a href="{{ route('purchaseRequestApprovalLevel1') }}" class="nav-link d-flex align-items-center"> <i class="fas fa-check-circle me-2"></i> <span>Approval Level 1</span> </a>
                        @endcan

                        @can('view-purchase-request-level-2')
                            <a href="{{ route('purchaseRequestApprovalLevel2') }}" class="nav-link d-flex align-items-center"> <i class="fas fa-check-circle me-2"></i> <span>Approval Level 2</span> </a>
                        @endcan

                        @can('view-purchase-request-level-3')
                            <a href="{{ route('purchaseRequestApprovalLevel3') }}" class="nav-link d-flex align-items-center"> <i class="fas fa-check-circle me-2"></i> <span>Approval Level 3</span> </a>
                        @endcan

                        @can('view-purchase-request-level-4')
                            <a href="{{ route('purchaseRequestApprovalLevel4') }}" class="nav-link d-flex align-items-center"> <i class="fas fa-check-circle me-2"></i> <span>Approval Level 4</span> </a>
                        @endcan

                        @can('view-purchase-request-level-5')
                            <a href="{{ route('purchaseRequestApprovalLevel5') }}" class="nav-link d-flex align-items-center"> <i class="fas fa-check-circle me-2"></i> <span>Approval Level 5</span> </a>
                        @endcan

                        @can('view-purchase-request-level-6')
                            <a href="{{ route('purchaseRequestApprovalLevel6') }}" class="nav-link d-flex align-items-center"> <i class="fas fa-check-circle me-2"></i> <span>Approval Level 6</span> </a>
                        @endcan
                    @endif

                    {{-- ── Procurement Configuration ── --}}
                    @can('view-procurement-types')
                        <a href="{{ route('procurementType') }}"
                        class="nav-link d-flex align-items-center">
                            <i class="fas fa-tags me-2"></i>
                            <span>Procurement Types</span>
                        </a>
                    @endcan

                    @can('view-procurement-workflow-steps')
                        <a href="{{ route('procurementWorkflowStep') }}"
                        class="nav-link d-flex align-items-center">
                            <i class="fas fa-list-check me-2"></i>
                            <span>Workflow Steps</span>
                        </a>
                    @endcan

                </div>
            </div>
        </div>
        @endcan


        {{-- ── Sales Menu ── --}}
        @can('view-sales-invoices-menu')
        <div class="nav-item">
            <a href="#salesSubmenu" class="nav-link" data-bs-toggle="collapse" role="button">
                <i class="fas fa-cash-register me-2"></i>
                <span>Sales Menu</span>
                <i class="fas fa-chevron-down ms-auto transition-toggle"></i>
            </a>
            <div class="collapse" id="salesSubmenu">
                <div class="ps-4 mt-2">
                    @can('view-customers')
                    <a href="{{ route('customer') }}" class="nav-link d-flex align-items-center">
                        <i class="fas fa-users me-2"></i> <span>Customers</span>
                    </a>
                    @endcan
                    @can('view-sales-invoices')
                    <a href="{{ route('salesinvoice') }}" class="nav-link d-flex align-items-center">
                        <i class="fas fa-file-invoice-dollar me-2"></i> <span>Sales Invoices</span>
                    </a>
                    @endcan
                    @can('view-customer-invoice-payments')
                    <a href="{{ route('customerPayment') }}" class="nav-link d-flex align-items-center">
                        <i class="fas fa-credit-card me-2"></i> <span>Customer Payments</span>
                    </a>
                    <a href="{{ route('customerPaymentinvoice') }}" class="nav-link d-flex align-items-center">
                        <i class="fas fa-file-invoice-dollar me-2"></i> <span>Add Invoice Sales</span>
                    </a>
                    @endcan
                    @can('view-stock-adjustments')
                    <a href="{{ route('stockOutsalesinvoice') }}" class="nav-link d-flex align-items-center">
                        <i class="fas fa-file-invoice-dollar me-2"></i> <span>Stock Out Sold Porducts</span>
                    </a>
                    @endcan
                </div>
            </div>
        </div>
        @endcan

    {{-- ── Supplier Menu ── --}}
    @can('view-suppliers-menu')
    <div class="nav-item">
        <a href="#supplierSubmenu"
        class="nav-link"
        data-bs-toggle="collapse"
        role="button"
        aria-expanded="false"
        aria-controls="supplierSubmenu">

            <i class="fas fa-truck me-2"></i>
            <span>Supplier Menu</span>
            <i class="fas fa-chevron-down ms-auto transition-toggle"></i>
        </a>

        <div class="collapse" id="supplierSubmenu">
            <div class="ps-4 mt-2">

                {{-- Supplier Information --}}
                @can('view-suppliers')
                <a href="{{ route('suppliers') }}"class="nav-link d-flex align-items-center"><i class="fas fa-building me-2"></i><span>Supplier Info</span></a>
                @endcan

                {{-- Supplier Categories --}}
                @can('view-supplier-categories')
                <a href="{{ route('supplierCategory') }}"class="nav-link d-flex align-items-center"><i class="fas fa-layer-group me-2"></i><span>supplier Categories </span></a>
                @endcan

                @can('view-supplier-payments')
                <a href="{{ route('supplierPayment') }}"class="nav-link d-flex align-items-center"><i class="fas fa-layer-group me-2"></i><span>supplier Payments</span></a>
                @endcan
                @can('view-supplier-invoices')
                <a href="{{ route('supplierInvoice') }}"class="nav-link d-flex align-items-center"><i class="fas fa-layer-group me-2"></i><span>supplier  Invoices </span></a>
                @endcan
                @can('view-supplier-awards')
                <a href="{{ route('goodsReceipt') }}"class="nav-link d-flex align-items-center"><i class="fas fa-layer-group me-2"></i><span>Goods Receipt </span></a>
                @endcan

                @can('view-supplier-awards')
                <a href="{{ route('purchaseOrder') }}"class="nav-link d-flex align-items-center"><i class="fas fa-layer-group me-2"></i><span>supplier purchaseOrderS</span></a>
                @endcan
                @can('view-supplier-awards')
                <a href="{{ route('supplierAward') }}"class="nav-link d-flex align-items-center"><i class="fas fa-layer-group me-2"></i><span>supplier Awards/contract</span></a>
                @endcan
                @can('view-purchase-quotations')
                <a href="{{ route('quotationEvaluation') }}"class="nav-link d-flex align-items-center"><i class="fas fa-layer-group me-2"></i><span>Quotation Evaluation</span></a>
                @endcan
                @can('view-purchase-quotations')
                <a href="{{ route('supplierQuotation') }}"class="nav-link d-flex align-items-center"><i class="fas fa-layer-group me-2"></i><span>Supplier Quotation</span></a>
                @endcan
                @can('view-supplier-tenders')
                <a href="{{ route('supplierTender') }}"class="nav-link d-flex align-items-center"><i class="fas fa-layer-group me-2"></i><span>Tenders Announcement</span></a>
                @endcan


            </div>
        </div>
    </div>
    @endcan

        @can('view-salary-menu')
        <div class="nav-item">
            <a href="#salarymenu" class="nav-link" data-bs-toggle="collapse">
                <i class="fas fa-money-check-alt nav-icon"></i>
                Salary Menu
                <i class="right fas fa-angle-left"></i>
            </a>
            <div id="salarymenu" class="collapse">
                @can('view-salary')
                <a href="{{ route('salarypay') }}" class="nav-link">
                    <i class="fas fa-wallet nav-icon"></i>
                    Monthly Salaries
                </a>
                @endcan

                <!-- @can('generate-salary')
                <a href="{{ route('registersalary') }}" class="nav-link">
                    <i class="fas fa-plus-circle nav-icon"></i>
                    Generate Salary
                </a>
                @endcan -->

                @can('pending-salary')
                <a href="{{ route('payrollApprovalIndex') }}" class="nav-link">
                    <i class="fas fa-clock nav-icon"></i>
                    Pending Approval
                </a>
                @endcan

                <!-- @can('pay-salary')
                <a href="{{ route('pendingpaysalary') }}" class="nav-link">
                    <i class="fas fa-credit-card nav-icon"></i>
                    Pending Payment
                </a>
                @endcan -->

                @can('view-staff-advance-salaries-menu')
                <a href="{{ route('staffadvncslries') }}" class="nav-link">
                    <i class="fas fa-hand-holding-usd nav-icon"></i>
                    Advance Salaries
                </a>
                @endcan

                @can('view-staff-overtimes-menu')
                <a href="{{ route('staffovertimes') }}" class="nav-link">
                    <i class="fas fa-business-time nav-icon"></i>
                    Staff Overtimes
                </a>
                @endcan

                @can('view-salary-allowances-menu')
                <a href="{{ route('slrallwncs') }}" class="nav-link">
                    <i class="fas fa-gift nav-icon"></i>
                    Salary Allowances
                </a>
                @endcan

                @can('view-staff-absent-calendars-menu')
                <a href="{{ route('staffabsentcalenders') }}" class="nav-link">
                    <i class="fas fa-calendar-times nav-icon"></i>
                    Absent Calendar
                </a>
                @endcan

                @can('view-staff-absents-menu')
                <a href="{{ route('staffabsent') }}" class="nav-link">
                    <i class="fas fa-calculator nav-icon"></i>
                    Absent Deductions
                </a>
                @endcan

                @can('salary-history')
                <a href="{{ route('salaryhistory') }}" class="nav-link">
                    <i class="fas fa-history nav-icon"></i>
                    Salary History
                </a>
                @endcan
            </div>
        </div>
        @endcan

        @can('view-share-purchases-menu')
        <div class="nav-item">
            <a href="#sharepurchasetransactions" class="nav-link" data-bs-toggle="collapse" role="button">
                <i class="fas fa-coins me-2"></i> <span>Share Purchases</span><i class="fas fa-chevron-down ms-auto"></i>
            </a>
            <div class="collapse" id="sharepurchasetransactions">
                <div class="ps-4 mt-2">
                    {{-- Main Overview Hub --}}
                    @can('view-share-purchases')
                    <a href="{{ route('sharepurchasetransactionshub') }}" class="nav-link d-flex align-items-center">
                        <i class="fas fa-cubes me-2"></i> <span>Share Purchases Hub</span>
                    </a>
                    @endcan
                    <!-- @can('view-share-purchases')
                    <a href="{{ route('sharepurchasetransactions') }}" class="nav-link d-flex align-items-center">
                        <i class="fas fa-cubes me-2"></i> <span>Share Purchases</span>
                    </a>
                    @endcan

                    {{-- Workflow Stage 1: Verification --}}
                    @can('verify-share-purchases')
                    <a href="{{ route('unverifiedsharepurchasetransactions') }}" class="nav-link d-flex align-items-center">
                        <i class="fas fa-shield-alt me-2"></i> <span>Pending Verification</span>
                    </a>
                    @endcan

                    {{-- Workflow Stage 2: Approval --}}
                    @can('approve-share-purchases')
                    <a href="{{ route('pendingapprovalsharepurchasetransactions') }}" class="nav-link d-flex align-items-center">
                        <i class="fas fa-user-check me-2"></i> <span>Pending Approval</span>
                    </a>
                    @endcan

                    {{-- Workflow Stage 3: Posting --}}
                    @can('post-share-purchases')
                    <a href="{{ route('pendingpostingsharepurchasetransactions') }}" class="nav-link d-flex align-items-center">
                        <i class="fas fa-file-invoice-dollar me-2"></i> <span>Pending Posting</span>
                    </a>
                    @endcan

                    {{-- Workflow Stage 4: Certificate Generation --}}
                    @can('generate-certificate-share-purchases')
                    <a href="{{ route('pendingcertificatesharepurchasetransactions') }}" class="nav-link d-flex align-items-center">
                        <i class="fas fa-certificate me-2"></i> <span>Pending Certificate</span>
                    </a>
                    @endcan

                    {{-- Final Stage: Archive & Completed --}}
                    @can('view-share-purchases')
                    <a href="{{ route('completedsharepurchasetransactions') }}" class="nav-link d-flex align-items-center">
                        <i class="fas fa-check-double me-2"></i> <span>Completed Purchases</span>
                    </a>
                    @endcan

                    {{-- Soft-Deleted Purchases --}}
                    @can('view-share-purchases')
                    <a href="{{ route('deletedsharepurchasetransactions') }}" class="nav-link d-flex align-items-center">
                        <i class="fas fa-trash-restore me-2"></i> <span>Deleted Purchases</span>
                    </a>
                    @endcan

                    {{-- Reports --}}
                    @can('view-share-purchases-report')
                    <a href="{{ route('sharepurchasetransactionsreport') }}" class="nav-link d-flex align-items-center">
                        <i class="fas fa-chart-bar me-2"></i> <span>Purchases Report</span>
                    </a>
                    @endcan -->
                </div>
            </div>
        </div>
        @endcan

        @can('view-membership-fees-menu')
        <div class="nav-item">
            <a href="#membershipfeepayments" class="nav-link" data-bs-toggle="collapse" role="button">
                <i class="fas fa-hand-holding-dollar me-2"></i> <span>Fees & Contributions</span><i class="fas fa-chevron-down ms-auto"></i>
            </a>
            <div class="collapse" id="membershipfeepayments">
                <div class="ps-4 mt-2">
                    @can('view-membership-fees')
                    <a href="{{ route('socialcontributionshub') }}" class="nav-link d-flex align-items-center"><i class="fas fa-hand-holding-heart me-2"></i> <span>Social Conts Hub</span></a>
                    <a href="{{ route('membershipfeepaymentshub') }}" class="nav-link d-flex align-items-center"><i class="fas fa-id-card me-2"></i> <span>Membership Fees Hub</span></a>
                    <a href="{{ route('socialcontributions') }}" class="nav-link d-flex align-items-center"><i class="fas fa-hand-holding-heart me-"></i> <span>Monthly Social Conts</span></a>
                    <a href="{{ route('membershipfeepayments') }}" class="nav-link d-flex align-items-center"><i class="fas fa-id-card me-2"></i> <span>Mbembership Fees</span></a>
                    @endcan
                    <!-- @can('view-membership-fees')
                    <a href="{{ route('deletedsocialcontributions') }}" class="nav-link d-flex align-items-center"><i class="fas fa-trash-arrow-up me-2"></i> <span>Deleted Members</span></a>
                    <a href="{{ route('deletedmembershipfeepayments') }}" class="nav-link d-flex align-items-center"><i class="fas fa-trash-arrow-up me-2"></i> <span>Deleted Members</span></a>
                    @endcan
                    @can('view-membership-fees-report')
                    <a href="{{ route('socialcontributionsreport') }}" class="nav-link d-flex align-items-center"><i class="fas fa-chart-bar me-2"></i> <span>Members Report</span></a>
                    <a href="{{ route('membershipfeepaymentsreport') }}" class="nav-link d-flex align-items-center"><i class="fas fa-chart-bar me-2"></i> <span>Members Report</span></a>
                    @endcan -->
                </div>
            </div>
        </div>
        @endcan
        @can('view-members-menu')
        <div class="nav-item">
            <a href="#membersSubmenu" class="nav-link" data-bs-toggle="collapse" role="button">
                <i class="fas fa-users me-2"></i> <span>Members Information</span><i class="fas fa-chevron-down ms-auto"></i>
            </a>
            <div class="collapse" id="membersSubmenu">
                <div class="ps-4 mt-2">
                    @can('view-members')
                    <a href="{{ route('memberinformations') }}" class="nav-link d-flex align-items-center"><i class="fas fa-eye me-2"></i> <span>View Members</span></a>
                    @endcan
                    @can('view-members')
                    <a href="{{ route('deletedmemberinformations') }}" class="nav-link d-flex align-items-center"><i class="fas fa-trash-arrow-up me-2"></i> <span>Deleted Members</span></a>
                    @endcan
                    @can('view-members-report')
                    <a href="{{ route('memberinformationsreport') }}" class="nav-link d-flex align-items-center"><i class="fas fa-chart-bar me-2"></i> <span>Members Report</span></a>
                    @endcan
                </div>
            </div>
        </div>
        @endcan
                {{-- ── Expenses Menu ── --}}
        @can('view-expenses-menu')
        <div class="nav-item">
            <a href="#expensesSubmenu" class="nav-link" data-bs-toggle="collapse" role="button">
                <i class="fas fa-receipt me-2"></i>
                <span>Expenses Menu</span>
                <i class="fas fa-chevron-down ms-auto transition-toggle"></i>
            </a>
            <div class="collapse" id="expensesSubmenu">
                <div class="ps-4 mt-2">
                    @can('view-expenses')
                    <a href="{{ route('expenseinformations') }}" class="nav-link d-flex align-items-center">
                        <i class="fas fa-file-invoice-dollar me-2"></i> <span>Expenses Info</span>
                    </a>
                    @endcan
                    @can('approve-expenses')
                    <a href="{{ route('approveexpenses') }}" class="nav-link d-flex align-items-center">
                        <i class="fas fa-check me-2"></i> <span>Approve Expenses</span>
                    </a>
                    @endcan
                    @can('view-expense-categories')
                    <a href="{{ route('expensecategoryinformations') }}" class="nav-link d-flex align-items-center">
                        <i class="fas fa-tags me-2"></i> <span>Expense Categories</span>
                    </a>
                    @endcan
                </div>
            </div>
        </div>
        @endcan
                {{-- ── Employee Menu ── --}}
        @can('view-employee-menu')
        <div class="nav-item">
            <a href="#employeeSubmenu" class="nav-link" data-bs-toggle="collapse" role="button">
                <i class="fas fa-users me-2"></i>
                <span>Employee Menu</span>
                <i class="fas fa-chevron-down ms-auto transition-toggle"></i>
            </a>
            <div class="collapse" id="employeeSubmenu">
                <div class="ps-4 mt-2">
                    @can('register-employees')
                    <a href="{{ route('employeeinfo') }}" class="nav-link d-flex align-items-center">
                        <i class="fas fa-building me-2"></i> <span>Company Employees</span>
                    </a>
                    <a href="#" class="nav-link d-flex align-items-center">
                        <i class="fas fa-user-slash me-2"></i> <span>Inactive Employees</span>
                    </a>
                    <a href="#" class="nav-link d-flex align-items-center">
                        <i class="fas fa-id-badge me-2"></i> <span>Employee Referees</span>
                    </a>
                    <a href="#" class="nav-link d-flex align-items-center">
                        <i class="fas fa-heart me-2"></i> <span>Employee Next of Kin</span>
                    </a>
                    @endcan
                </div>
            </div>
        </div>
        @endcan
        <form method="POST" action="{{ route('logout') }}" class="mt-auto">
            @csrf
            <button type="submit" 
                class="nav-link text-start w-100" style="background: none; border: none;">
                <i class="bi bi-box-arrow-right"></i>
                <span>Logout</span>
            </button>
        </form>
    </nav>
</aside>